<?php
/**
 * Created by PhpStorm.
 * User: archi.parikh
 * Date: 11/17/2017
 * Time: 8:14 PM
 */

namespace App\DataConverter;

/**
 * Class XMLConverter
 * @package App\DataConverter
 */
class XMLConverter {

    /**
     * @param $fileContent
     * @return string
     */
    public static function toJSON($fileContent) {
        $simpleXml = simplexml_load_string($fileContent);

        $json = json_encode($simpleXml, JSON_PRETTY_PRINT);

        return $json;
    }
}