<?php
/**
 * Created by PhpStorm.
 * User: archi.parikh
 * Date: 11/17/2017
 * Time: 8:39 PM
 */
namespace App\DataConverter;

/**
 * Interface DataConverterInterface
 * @package App\DataConverter
 */
interface DataConverterInterface {

    /**
     * @return mixed
     */
    public function supportsConvert();

    /**
     * @return mixed
     */
    public function convert();
}