<?php
/**
 * Created by PhpStorm.
 * User: archi.parikh
 * Date: 11/17/2017
 * Time: 8:15 PM
 */

namespace App\DataConverter;

/**
 * Class JSONConverter
 * @package App\DataConverter
 */
class JSONConverter {

    /**
     * @param $fileContent
     * @return string
     */
    public static function toXML($fileContent) {
        $dataArray = json_decode($fileContent, true);

        $xml = self::Array2xml($dataArray);

        $dom = dom_import_simplexml($xml)->ownerDocument;
        $dom->formatOutput = true;

        return $dom->saveXML();
    }

    /**
     * @param $array
     * @param bool $xml
     * @return bool|\SimpleXMLElement
     */
    private static function Array2xml($array, $xml = false){

        if($xml === false){
            $xml = new \SimpleXMLElement('<root/>');
        }
        foreach($array as $key => $value){
            if(is_array($value)){
                $key = (is_int($key)) ? 'address'.$key : $key;

                self::Array2xml($value, $xml->addChild($key));
            } else {
                $xml->addChild($key, htmlspecialchars($value));
            }
        }

        return $xml;
    }
}