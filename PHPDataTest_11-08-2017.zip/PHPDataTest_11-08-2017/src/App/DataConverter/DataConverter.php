<?php
/**
 * Created by PhpStorm.
 * User: archi.parikh
 * Date: 11/17/2017
 * Time: 8:18 PM
 */

namespace App\DataConverter;

use Symfony\Component\Console\Exception\InvalidArgumentException;

/**
 * Class DataConverter
 * @package App\DataConverter
 */
class DataConverter implements DataConverterInterface {

    /**
     * @var object
     */
    private $file;

    /**
     * @var string
     */
    private $outputFormat;

    /**
     * @var string
     */
    private $converter;

    /**
     * @var string
     */
    private $methodName;

    /**
     * DataConverter constructor.
     * @param object $file
     * @param string $outputFormat
     */
    public function __construct($file, $outputFormat)
    {
        $this->file = $file;
        $this->outputFormat = $outputFormat;

        $this->converter = 'App\DataConverter\\'.strtoupper(pathinfo($file, PATHINFO_EXTENSION)).'Converter';
        $this->methodName = 'to'.strtoupper($outputFormat);
    }

    /**
     * @throws InvalidArgumentException
     * @return boolean
     */
    public function supportsConvert()
    {
        if(! $this->file) {
            throw new InvalidArgumentException('File not found.');
        }

        if(! $this->converter) {
            throw new InvalidArgumentException('Input format is not supported.');
        }

        if(! method_exists($this->converter, $this->methodName)) {
            throw new InvalidArgumentException('Output Format is not supported.');
        }

        return true;
    }

    /**
     * @throws InvalidArgumentException
     * @return string
     */
    public function convert()
    {
        if(! $this->supportsConvert()) {
            throw new InvalidArgumentException('This conversion is not supported.');
        }

        $converter = $this->converter;
        $method = $this->methodName;

        return $converter::$method(file_get_contents($this->file));
    }
}